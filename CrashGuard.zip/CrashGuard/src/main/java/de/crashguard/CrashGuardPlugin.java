package de.crashguard;

import de.crashguard.commands.CrashGuardCommand;
import de.crashguard.config.ConfigurationManager;
import de.crashguard.listeners.PacketInterceptor;
import de.crashguard.protection.ProtectionManager;
import de.crashguard.utils.MetricsCollector;
import de.crashguard.utils.WhitelistManager;
import de.crashguard.utils.ErrorHandler;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;

public final class CrashGuardPlugin extends JavaPlugin {
    
    private static CrashGuardPlugin pluginInstance;
    private ConfigurationManager configurationHandler;
    private ProtectionManager protectionSystem;
    private PacketInterceptor eventListener;
    private MetricsCollector statisticsTracker;
    private WhitelistManager accessController;
    private ErrorHandler exceptionManager;
    
    @Override
    public void onEnable() {
        pluginInstance = this;
        
        this.configurationHandler = new ConfigurationManager(this);
        this.configurationHandler.loadConfiguration();
        
        this.exceptionManager = new ErrorHandler(this);
        this.statisticsTracker = new MetricsCollector();
        this.accessController = new WhitelistManager(this);
        this.protectionSystem = new ProtectionManager(this);
        this.eventListener = new PacketInterceptor(this);
        
        getServer().getPluginManager().registerEvents(eventListener, this);
        
        CrashGuardCommand cmdHandler = new CrashGuardCommand(this);
        getCommand("crashguard").setExecutor(cmdHandler);
        getCommand("crashguard").setTabCompleter(cmdHandler);
        
        getLogger().info("CrashGuard v" + getDescription().getVersion() + " loaded successfully");
        getLogger().info("Advanced protection systems are now active");
    }
    
    @Override
    public void onDisable() {
        if (eventListener != null) {
            eventListener.shutdown();
        }
        
        if (statisticsTracker != null) {
            statisticsTracker.shutdown();
        }
        
        getLogger().info("CrashGuard has been disabled");
        pluginInstance = null;
    }
    
    @NotNull
    public static CrashGuardPlugin getInstance() {
        return pluginInstance;
    }
    
    @NotNull
    public ConfigurationManager getConfigManager() {
        return configurationHandler;
    }
    
    @NotNull
    public ProtectionManager getProtectionManager() {
        return protectionSystem;
    }
    
    @NotNull
    public MetricsCollector getMetricsCollector() {
        return statisticsTracker;
    }
    
    @NotNull
    public WhitelistManager getWhitelistManager() {
        return accessController;
    }
    
    @NotNull
    public ErrorHandler getErrorHandler() {
        return exceptionManager;
    }
}
