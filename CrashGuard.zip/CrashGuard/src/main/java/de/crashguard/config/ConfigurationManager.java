package de.crashguard.config;

import de.crashguard.CrashGuardPlugin;
import org.bukkit.configuration.file.FileConfiguration;
import org.jetbrains.annotations.NotNull;

public final class ConfigurationManager {
    
    private final CrashGuardPlugin plugin;
    private FileConfiguration config;
    
    public ConfigurationManager(@NotNull CrashGuardPlugin plugin) {
        this.plugin = plugin;
    }
    
    public void loadConfiguration() {
        plugin.saveDefaultConfig();
        plugin.reloadConfig();
        this.config = plugin.getConfig();
        
        validateConfiguration();
    }
    
    private void validateConfiguration() {
        if (!config.contains("protection.creative-inventory.enabled")) {
            config.set("protection.creative-inventory.enabled", true);
        }
        
        if (!config.contains("protection.creative-inventory.max-packets-per-second")) {
            config.set("protection.creative-inventory.max-packets-per-second", 25);
        }
        
        if (!config.contains("protection.creative-inventory.max-nbt-depth")) {
            config.set("protection.creative-inventory.max-nbt-depth", 10);
        }
        
        if (!config.contains("protection.creative-inventory.max-nbt-size")) {
            config.set("protection.creative-inventory.max-nbt-size", 65536);
        }
        
        if (!config.contains("protection.creative-inventory.max-bundle-items")) {
            config.set("protection.creative-inventory.max-bundle-items", 64);
        }
        
        if (!config.contains("protection.creative-inventory.invalid-slot-threshold")) {
            config.set("protection.creative-inventory.invalid-slot-threshold", 8);
        }
        
        if (!config.contains("protection.advanced-detection.enabled")) {
            config.set("protection.advanced-detection.enabled", true);
        }
        
        if (!config.contains("protection.false-positive-reduction.enabled")) {
            config.set("protection.false-positive-reduction.enabled", true);
        }
        
        if (!config.contains("protection.kick-message")) {
            config.set("protection.kick-message", "§cVerbindung getrennt: Verdächtige Aktivität erkannt");
        }
        
        if (!config.contains("protection.notify-admins")) {
            config.set("protection.notify-admins", true);
        }
        
        if (!config.contains("performance.async-processing")) {
            config.set("performance.async-processing", true);
        }
        
        if (!config.contains("performance.cache-size")) {
            config.set("performance.cache-size", 2000);
        }
        
        if (!config.contains("performance.thread-pool-size")) {
            config.set("performance.thread-pool-size", 6);
        }
        
        plugin.saveConfig();
    }
    
    public boolean isCreativeInventoryProtectionEnabled() {
        return config.getBoolean("protection.creative-inventory.enabled", true);
    }
    
    public int getMaxPacketsPerSecond() {
        return config.getInt("protection.creative-inventory.max-packets-per-second", 25);
    }
    
    public int getMaxNbtDepth() {
        return config.getInt("protection.creative-inventory.max-nbt-depth", 10);
    }
    
    public int getMaxNbtSize() {
        return config.getInt("protection.creative-inventory.max-nbt-size", 65536);
    }
    
    public int getMaxBundleItems() {
        return config.getInt("protection.creative-inventory.max-bundle-items", 64);
    }
    
    public int getInvalidSlotThreshold() {
        return config.getInt("protection.creative-inventory.invalid-slot-threshold", 8);
    }
    
    public boolean isAdvancedDetectionEnabled() {
        return config.getBoolean("protection.advanced-detection.enabled", true);
    }
    
    public boolean isFalsePositiveReductionEnabled() {
        return config.getBoolean("protection.false-positive-reduction.enabled", true);
    }
    
    public boolean isPatternMatchingEnabled() {
        return config.getBoolean("protection.advanced-detection.pattern-matching", true);
    }
    
    public boolean isNbtAnalysisEnabled() {
        return config.getBoolean("protection.advanced-detection.nbt-analysis", true);
    }
    
    public boolean isBundleProtectionEnabled() {
        return config.getBoolean("protection.advanced-detection.bundle-protection", true);
    }
    
    public boolean isBookProtectionEnabled() {
        return config.getBoolean("protection.advanced-detection.book-protection", true);
    }
    
    public String getKickMessage() {
        return config.getString("protection.kick-message", "§cVerbindung getrennt: Verdächtige Aktivität erkannt");
    }
    
    public boolean shouldNotifyAdmins() {
        return config.getBoolean("protection.notify-admins", true);
    }
    
    public boolean isAsyncProcessingEnabled() {
        return config.getBoolean("performance.async-processing", true);
    }
    
    public int getCacheSize() {
        return config.getInt("performance.cache-size", 2000);
    }
    
    public int getThreadPoolSize() {
        return config.getInt("performance.thread-pool-size", 6);
    }
    
    public int getCleanupInterval() {
        return config.getInt("performance.cleanup-interval", 300);
    }
    
    public boolean isDebugEnabled() {
        return config.getBoolean("logging.debug", false);
    }
    
    public boolean shouldLogBlockedAttempts() {
        return config.getBoolean("logging.log-blocked-attempts", true);
    }
    
    public boolean shouldLogFalsePositives() {
        return config.getBoolean("logging.log-false-positives", true);
    }
    
    public void reloadConfiguration() {
        loadConfiguration();
    }
}
