package de.crashguard.commands;

import de.crashguard.CrashGuardPlugin;
import de.crashguard.utils.MetricsCollector;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class CrashGuardCommand implements CommandExecutor, TabCompleter {
    
    private final CrashGuardPlugin plugin;
    
    public CrashGuardCommand(@NotNull CrashGuardPlugin plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, 
                           @NotNull String label, @NotNull String[] args) {
        
        if (!sender.hasPermission("crashguard.admin")) {
            sender.sendMessage("§c[CrashGuard] §fKeine Berechtigung für diesen Befehl.");
            return true;
        }
        
        if (args.length == 0) {
            sendHelpMessage(sender);
            return true;
        }
        
        switch (args[0].toLowerCase()) {
            case "reload":
                handleReload(sender);
                break;
            case "status":
                handleStatus(sender);
                break;
            case "info":
                handleInfo(sender);
                break;
            case "metrics":
                handleMetrics(sender);
                break;
            case "clear":
                handleClear(sender, args);
                break;
            case "whitelist":
                handleWhitelist(sender, args);
                break;
            case "errors":
                handleErrors(sender, args);
                break;
            case "test":
                handleTest(sender, args);
                break;
            default:
                sendHelpMessage(sender);
                break;
        }
        
        return true;
    }
    
    private void handleReload(@NotNull CommandSender sender) {
        try {
            plugin.getConfigManager().reloadConfiguration();
            sender.sendMessage("§a[CrashGuard] §fKonfiguration erfolgreich neu geladen.");
        } catch (Exception e) {
            sender.sendMessage("§c[CrashGuard] §fFehler beim Neuladen der Konfiguration: " + e.getMessage());
        }
    }
    
    private void handleStatus(@NotNull CommandSender sender) {
        boolean protectionEnabled = plugin.getConfigManager().isCreativeInventoryProtectionEnabled();
        int maxPackets = plugin.getConfigManager().getMaxPacketsPerSecond();
        int maxNbtSize = plugin.getConfigManager().getMaxNbtSize();
        
        sender.sendMessage("§6[CrashGuard] §fStatus:");
        sender.sendMessage("§7- Schutz aktiv: " + (protectionEnabled ? "§aJa" : "§cNein"));
        sender.sendMessage("§7- Max. Pakete/Sek: §b" + maxPackets);
        sender.sendMessage("§7- Max. NBT-Größe: §b" + maxNbtSize + " Bytes");
        sender.sendMessage("§7- Version: §b" + plugin.getDescription().getVersion());
    }
    
    private void handleInfo(@NotNull CommandSender sender) {
        sender.sendMessage("§6[CrashGuard] §fPlugin-Informationen:");
        sender.sendMessage("§7- Name: §bCrashGuard");
        sender.sendMessage("§7- Version: §b" + plugin.getDescription().getVersion());
        sender.sendMessage("§7- Autor: §bCrashGuard-Team");
        sender.sendMessage("§7- API-Version: §b" + plugin.getDescription().getAPIVersion());
        sender.sendMessage("§7- Beschreibung: §b" + plugin.getDescription().getDescription());
    }
    
    private void handleMetrics(@NotNull CommandSender sender) {
        MetricsCollector metrics = plugin.getMetricsCollector();
        
        long packetsProcessed = metrics.getPacketsProcessed();
        long violationsDetected = metrics.getViolationsDetected();
        long playersKicked = metrics.getPlayersKicked();
        long uptimeMillis = metrics.getUptimeMillis();
        double packetsPerSecond = metrics.getPacketsPerSecond();
        
        long uptimeSeconds = uptimeMillis / 1000;
        long hours = uptimeSeconds / 3600;
        long minutes = (uptimeSeconds % 3600) / 60;
        long seconds = uptimeSeconds % 60;
        
        sender.sendMessage("§6[CrashGuard] §fStatistiken:");
        sender.sendMessage("§7- Verarbeitete Pakete: §b" + packetsProcessed);
        sender.sendMessage("§7- Erkannte Verstöße: §b" + violationsDetected);
        sender.sendMessage("§7- Gekickte Spieler: §b" + playersKicked);
        sender.sendMessage("§7- Laufzeit: §b" + hours + "h " + minutes + "m " + seconds + "s");
        sender.sendMessage("§7- Pakete/Sek: §b" + String.format("%.2f", packetsPerSecond));
    }
    
    private void handleClear(@NotNull CommandSender sender, @NotNull String[] args) {
        if (args.length < 2) {
            sender.sendMessage("§c[CrashGuard] §fVerwendung: /crashguard clear <spieler|metrics>");
            return;
        }
        
        if (args[1].equalsIgnoreCase("metrics")) {
            plugin.getMetricsCollector().reset();
            sender.sendMessage("§a[CrashGuard] §fStatistiken zurückgesetzt.");
        } else {
            String playerName = args[1];
            plugin.getProtectionManager().clearViolations(playerName);
            sender.sendMessage("§a[CrashGuard] §fVerstöße für Spieler §b" + playerName + " §fzurückgesetzt.");
        }
    }
    
    private void handleWhitelist(@NotNull CommandSender sender, @NotNull String[] args) {
        if (args.length < 2) {
            sender.sendMessage("§c[CrashGuard] §fVerwendung: /crashguard whitelist <add|remove|list> [player|material]");
            return;
        }
        
        switch (args[1].toLowerCase()) {
            case "add":
                if (args.length < 4) {
                    sender.sendMessage("§c[CrashGuard] §fVerwendung: /crashguard whitelist add <player|material> <name>");
                    return;
                }
                handleWhitelistAdd(sender, args[2], args[3]);
                break;
            case "remove":
                if (args.length < 4) {
                    sender.sendMessage("§c[CrashGuard] §fVerwendung: /crashguard whitelist remove <player|material> <name>");
                    return;
                }
                handleWhitelistRemove(sender, args[2], args[3]);
                break;
            case "list":
                handleWhitelistList(sender);
                break;
            default:
                sender.sendMessage("§c[CrashGuard] §fUnbekannter Whitelist-Befehl");
                break;
        }
    }
    
    private void handleWhitelistAdd(@NotNull CommandSender sender, @NotNull String type, @NotNull String name) {
        if (type.equalsIgnoreCase("player")) {
            plugin.getWhitelistManager().addWhitelistedPlayer(name);
            sender.sendMessage("§a[CrashGuard] §fSpieler §b" + name + " §fzur Whitelist hinzugefügt");
        } else if (type.equalsIgnoreCase("material")) {
            try {
                org.bukkit.Material material = org.bukkit.Material.valueOf(name.toUpperCase());
                plugin.getWhitelistManager().addWhitelistedMaterial(material);
                sender.sendMessage("§a[CrashGuard] §fMaterial §b" + material.name() + " §fzur Whitelist hinzugefügt");
            } catch (IllegalArgumentException e) {
                sender.sendMessage("§c[CrashGuard] §fUngültiges Material: " + name);
            }
        } else {
            sender.sendMessage("§c[CrashGuard] §fTyp muss 'player' oder 'material' sein");
        }
    }
    
    private void handleWhitelistRemove(@NotNull CommandSender sender, @NotNull String type, @NotNull String name) {
        if (type.equalsIgnoreCase("player")) {
            plugin.getWhitelistManager().removeWhitelistedPlayer(name);
            sender.sendMessage("§a[CrashGuard] §fSpieler §b" + name + " §fvon der Whitelist entfernt");
        } else if (type.equalsIgnoreCase("material")) {
            try {
                org.bukkit.Material material = org.bukkit.Material.valueOf(name.toUpperCase());
                plugin.getWhitelistManager().removeWhitelistedMaterial(material);
                sender.sendMessage("§a[CrashGuard] §fMaterial §b" + material.name() + " §fvon der Whitelist entfernt");
            } catch (IllegalArgumentException e) {
                sender.sendMessage("§c[CrashGuard] §fUngültiges Material: " + name);
            }
        } else {
            sender.sendMessage("§c[CrashGuard] §fTyp muss 'player' oder 'material' sein");
        }
    }
    
    private void handleWhitelistList(@NotNull CommandSender sender) {
        sender.sendMessage("§6[CrashGuard] §fWhitelist:");
        sender.sendMessage("§7Spieler: §b" + plugin.getWhitelistManager().getWhitelistedPlayers().size());
        sender.sendMessage("§7Materialien: §b" + plugin.getWhitelistManager().getWhitelistedMaterials().size());
    }
    
    private void handleErrors(@NotNull CommandSender sender, @NotNull String[] args) {
        if (args.length < 2) {
            sender.sendMessage("§c[CrashGuard] §fVerwendung: /crashguard errors <reset|debug>");
            return;
        }
        
        switch (args[1].toLowerCase()) {
            case "reset":
                plugin.getErrorHandler().resetAllErrorCounts();
                sender.sendMessage("§a[CrashGuard] §fAlle Fehlerzähler zurückgesetzt");
                break;
            case "debug":
                boolean debug = !plugin.getConfigManager().isDebugEnabled();
                plugin.getConfig().set("logging.debug", debug);
                plugin.saveConfig();
                sender.sendMessage("§a[CrashGuard] §fDebug-Modus: " + (debug ? "§aAktiviert" : "§cDeaktiviert"));
                break;
            default:
                sender.sendMessage("§c[CrashGuard] §fUnbekannter Error-Befehl");
                break;
        }
    }
    
    private void handleTest(@NotNull CommandSender sender, @NotNull String[] args) {
        if (!(sender instanceof org.bukkit.entity.Player player)) {
            sender.sendMessage("§c[CrashGuard] §fDieser Befehl kann nur von Spielern verwendet werden");
            return;
        }
        
        if (args.length < 2) {
            sender.sendMessage("§c[CrashGuard] §fVerwendung: /crashguard test <item|protection>");
            return;
        }
        
        switch (args[1].toLowerCase()) {
            case "item":
                org.bukkit.inventory.ItemStack item = player.getInventory().getItemInMainHand();
                if (item.getType() == org.bukkit.Material.AIR) {
                    sender.sendMessage("§c[CrashGuard] §fHalte ein Item in der Hand");
                    return;
                }
                
                boolean safe = plugin.getWhitelistManager().isItemWhitelisted(item);
                sender.sendMessage("§6[CrashGuard] §fItem-Test: " + (safe ? "§aSicher" : "§cUnsicher"));
                break;
            case "protection":
                sender.sendMessage("§6[CrashGuard] §fSchutz-Test gestartet...");
                sender.sendMessage("§7- Creative Protection: " + 
                    (plugin.getConfigManager().isCreativeInventoryProtectionEnabled() ? "§aAktiv" : "§cInaktiv"));
                sender.sendMessage("§7- Advanced Detection: " + 
                    (plugin.getConfigManager().isAdvancedDetectionEnabled() ? "§aAktiv" : "§cInaktiv"));
                sender.sendMessage("§7- Whitelist Status: " + 
                    (plugin.getWhitelistManager().isPlayerWhitelisted(player) ? "§aGewhitelistet" : "§cNicht gewhitelistet"));
                break;
            default:
                sender.sendMessage("§c[CrashGuard] §fUnbekannter Test-Befehl");
                break;
        }
    }
    
    private void sendHelpMessage(@NotNull CommandSender sender) {
        sender.sendMessage("§6[CrashGuard] §fVerfügbare Befehle:");
        sender.sendMessage("§7- §b/crashguard reload §7- Konfiguration neu laden");
        sender.sendMessage("§7- §b/crashguard status §7- Plugin-Status anzeigen");
        sender.sendMessage("§7- §b/crashguard info §7- Plugin-Informationen");
        sender.sendMessage("§7- §b/crashguard metrics §7- Statistiken anzeigen");
        sender.sendMessage("§7- §b/crashguard clear <spieler|metrics> §7- Daten zurücksetzen");
        sender.sendMessage("§7- §b/crashguard whitelist <add|remove|list> §7- Whitelist verwalten");
        sender.sendMessage("§7- §b/crashguard errors <reset|debug> §7- Fehler verwalten");
        sender.sendMessage("§7- §b/crashguard test <item|protection> §7- Tests durchführen");
    }
    
    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, 
                                              @NotNull String alias, @NotNull String[] args) {
        
        if (!sender.hasPermission("crashguard.admin")) {
            return new ArrayList<>();
        }
        
        if (args.length == 1) {
            List<String> completions = Arrays.asList("reload", "status", "info", "metrics", "clear", "whitelist", "errors", "test");
            return filterCompletions(completions, args[0]);
        }
        
        if (args.length == 2 && args[0].equalsIgnoreCase("clear")) {
            List<String> completions = new ArrayList<>();
            completions.add("metrics");
            
            plugin.getServer().getOnlinePlayers().forEach(player -> 
                completions.add(player.getName()));
            
            return filterCompletions(completions, args[1]);
        }
        
        return new ArrayList<>();
    }
    
    private List<String> filterCompletions(@NotNull List<String> completions, @NotNull String input) {
        List<String> filtered = new ArrayList<>();
        String lowerInput = input.toLowerCase();
        
        for (String completion : completions) {
            if (completion.toLowerCase().startsWith(lowerInput)) {
                filtered.add(completion);
            }
        }
        
        return filtered;
    }
}
