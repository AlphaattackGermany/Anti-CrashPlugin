package de.crashguard.protection;

import de.crashguard.CrashGuardPlugin;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;

public final class ProtectionManager {
    
    private final CrashGuardPlugin plugin;
    private final ConcurrentHashMap<String, ViolationRecord> violationRecords;
    
    private static final int MAX_VIOLATIONS_PER_MINUTE = 3;
    private static final long VIOLATION_RESET_TIME = 60000L;
    
    public ProtectionManager(@NotNull CrashGuardPlugin plugin) {
        this.plugin = plugin;
        this.violationRecords = new ConcurrentHashMap<>();
        
        startViolationCleanupTask();
    }
    
    private void startViolationCleanupTask() {
        plugin.getServer().getScheduler().runTaskTimerAsynchronously(plugin, () -> {
            long currentTime = System.currentTimeMillis();
            
            violationRecords.entrySet().removeIf(entry -> {
                ViolationRecord record = entry.getValue();
                if (currentTime - record.getLastViolationTime() > VIOLATION_RESET_TIME * 5) {
                    return true;
                }
                
                if (currentTime - record.getLastViolationTime() > VIOLATION_RESET_TIME) {
                    record.resetViolations();
                }
                
                return false;
            });
        }, 1200L, 1200L);
    }
    
    public void handleViolation(@NotNull Player player, @NotNull String reason) {
        if (player.hasPermission("crashguard.bypass")) {
            return;
        }
        
        String playerName = player.getName();
        ViolationRecord record = violationRecords.computeIfAbsent(playerName, k -> new ViolationRecord());
        
        record.addViolation();
        
        plugin.getLogger().log(Level.WARNING, 
            "Spieler {0} hat eine Schutzregel verletzt: {1} (Verstöße: {2})", 
            new Object[]{playerName, reason, record.getViolationCount()});
        
        if (plugin.getConfigManager().shouldNotifyAdmins()) {
            notifyAdmins(playerName, reason, record.getViolationCount());
        }
        
        if (record.getViolationCount() >= MAX_VIOLATIONS_PER_MINUTE) {
            kickPlayer(player, reason);
        } else {
            warnPlayer(player, reason);
        }
        
        plugin.getMetricsCollector().incrementViolationsDetected();
    }
    
    private void kickPlayer(@NotNull Player player, @NotNull String reason) {
        String kickMessage = plugin.getConfigManager().getKickMessage();
        
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (player.isOnline()) {
                player.kickPlayer(kickMessage);
                
                plugin.getLogger().log(Level.INFO, 
                    "Spieler {0} wurde wegen verdächtiger Aktivität gekickt: {1}", 
                    new Object[]{player.getName(), reason});
            }
        });
        
        plugin.getMetricsCollector().incrementPlayersKicked();
    }
    
    private void warnPlayer(@NotNull Player player, @NotNull String reason) {
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (player.isOnline()) {
                player.sendMessage("§c[CrashGuard] §fVerdächtige Aktivität erkannt. Weitere Verstöße führen zum Kick.");
            }
        });
    }
    
    private void notifyAdmins(@NotNull String playerName, @NotNull String reason, int violationCount) {
        String message = String.format("§c[CrashGuard] §f%s: %s (Verstöße: %d)", 
            playerName, reason, violationCount);
        
        Bukkit.getScheduler().runTask(plugin, () -> {
            for (Player admin : Bukkit.getOnlinePlayers()) {
                if (admin.hasPermission("crashguard.notify")) {
                    admin.sendMessage(message);
                }
            }
        });
    }
    
    public int getViolationCount(@NotNull String playerName) {
        ViolationRecord record = violationRecords.get(playerName);
        return record != null ? record.getViolationCount() : 0;
    }
    
    public void clearViolations(@NotNull String playerName) {
        violationRecords.remove(playerName);
    }
    
    private static final class ViolationRecord {
        private final AtomicInteger violationCount;
        private volatile long lastViolationTime;
        
        public ViolationRecord() {
            this.violationCount = new AtomicInteger(0);
            this.lastViolationTime = System.currentTimeMillis();
        }
        
        public void addViolation() {
            violationCount.incrementAndGet();
            lastViolationTime = System.currentTimeMillis();
        }
        
        public int getViolationCount() {
            return violationCount.get();
        }
        
        public long getLastViolationTime() {
            return lastViolationTime;
        }
        
        public void resetViolations() {
            violationCount.set(0);
        }
    }
}
