package de.crashguard.listeners;

import de.crashguard.CrashGuardPlugin;
import de.crashguard.protection.ProtectionManager;
import de.crashguard.utils.NBTAnalyzer;
import de.crashguard.utils.RateLimiter;
import de.crashguard.utils.CrashPatternDetector;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCreativeEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.jetbrains.annotations.NotNull;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

public final class PacketInterceptor implements Listener {
    
    private final CrashGuardPlugin mainPlugin;
    private final ProtectionManager securitySystem;
    private final RateLimiter packetLimiter;
    private final NBTAnalyzer dataValidator;
    private final CrashPatternDetector patternMatcher;
    private final ExecutorService workerPool;
    
    private final ConcurrentHashMap<String, AtomicInteger> invalidSlotAttempts;
    private final ConcurrentHashMap<String, AtomicLong> lastEventTime;
    private final ConcurrentHashMap<String, AtomicInteger> creativeEventCount;
    
    public PacketInterceptor(@NotNull CrashGuardPlugin plugin) {
        this.mainPlugin = plugin;
        this.securitySystem = plugin.getProtectionManager();
        this.packetLimiter = new RateLimiter(plugin);
        this.dataValidator = new NBTAnalyzer(plugin);
        this.patternMatcher = new CrashPatternDetector(plugin);
        this.workerPool = Executors.newFixedThreadPool(6, r -> {
            Thread t = new Thread(r, "GuardWorker-" + System.nanoTime());
            t.setDaemon(true);
            t.setPriority(Thread.NORM_PRIORITY);
            t.setUncaughtExceptionHandler((thread, ex) -> 
                plugin.getLogger().warning("Worker thread error: " + ex.getMessage()));
            return t;
        });
        
        this.invalidSlotAttempts = new ConcurrentHashMap<>();
        this.lastEventTime = new ConcurrentHashMap<>();
        this.creativeEventCount = new ConcurrentHashMap<>();
        
        startCleanupTask();
    }
    
    private void startCleanupTask() {
        Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, () -> {
            long currentTime = System.currentTimeMillis();
            
            lastEventTime.entrySet().removeIf(entry -> {
                if (currentTime - entry.getValue().get() > 300000L) {
                    invalidSlotAttempts.remove(entry.getKey());
                    creativeEventCount.remove(entry.getKey());
                    return true;
                }
                return false;
            });
        }, 6000L, 6000L);
    }
    
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
    public void onInventoryCreative(@NotNull InventoryCreativeEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        
        if (mainPlugin.getWhitelistManager().isPlayerWhitelisted(player)) {
            return;
        }
        
        if (!mainPlugin.getConfigManager().isCreativeInventoryProtectionEnabled()) {
            return;
        }
        
        String playerName = player.getName();
        
        if (!packetLimiter.isAllowed(playerName)) {
            event.setCancelled(true);
            securitySystem.handleViolation(player, "Creative inventory rate limit exceeded");
            return;
        }
        
        AtomicInteger eventCount = creativeEventCount.computeIfAbsent(playerName, k -> new AtomicInteger(0));
        AtomicLong lastTime = lastEventTime.computeIfAbsent(playerName, k -> new AtomicLong(System.currentTimeMillis()));
        
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastTime.get() < 50) {
            if (eventCount.incrementAndGet() > 10) {
                event.setCancelled(true);
                protectionManager.handleViolation(player, "Creative inventory spam detected");
                return;
            }
        } else {
            eventCount.set(0);
            lastTime.set(currentTime);
        }
        
        int slot = event.getSlot();
        ItemStack currentItem = event.getCurrentItem();
        ItemStack cursorItem = event.getCursor();
        
        if (plugin.getWhitelistManager().isItemWhitelisted(currentItem) && 
            plugin.getWhitelistManager().isItemWhitelisted(cursorItem)) {
            return;
        }
        
        if (isInvalidSlot(slot)) {
            AtomicInteger attempts = invalidSlotAttempts.computeIfAbsent(playerName, k -> new AtomicInteger(0));
            if (attempts.incrementAndGet() > plugin.getConfigManager().getInvalidSlotThreshold()) {
                event.setCancelled(true);
                protectionManager.handleViolation(player, "Invalid slot access attempt: " + slot);
                return;
            }
        }
        
        if (plugin.getConfigManager().isAsyncProcessingEnabled()) {
            executorService.submit(() -> analyzeCreativeEventAsync(player, event, currentItem, cursorItem));
        } else {
            if (!analyzeCreativeEventSync(player, currentItem, cursorItem)) {
                event.setCancelled(true);
            }
        }
        
        plugin.getMetricsCollector().incrementPacketsProcessed();
    }
    
    private void analyzeCreativeEventAsync(@NotNull Player player, @NotNull InventoryCreativeEvent event, 
                                         ItemStack currentItem, ItemStack cursorItem) {
        try {
            if (!analyzeCreativeEventSync(player, currentItem, cursorItem)) {
                Bukkit.getScheduler().runTask(plugin, () -> {
                    if (player.isOnline() && !event.isCancelled()) {
                        event.setCancelled(true);
                        protectionManager.handleViolation(player, "Malicious creative inventory item detected");
                    }
                });
            }
        } catch (Exception e) {
            plugin.getErrorHandler().handleError("AsyncCreativeEventAnalysis", e, 
                "Player: " + player.getName());
        }
    }
    
    private boolean analyzeCreativeEventSync(@NotNull Player player, ItemStack currentItem, ItemStack cursorItem) {
        try {
            if (currentItem != null && !nbtAnalyzer.isItemStackSafe(currentItem)) {
                return false;
            }
            
            if (cursorItem != null && !nbtAnalyzer.isItemStackSafe(cursorItem)) {
                return false;
            }
            
            if (currentItem != null && !crashDetector.isItemSafe(currentItem, player)) {
                return false;
            }
            
            if (cursorItem != null && !crashDetector.isItemSafe(cursorItem, player)) {
                return false;
            }
            
            return true;
        } catch (Exception e) {
            plugin.getErrorHandler().handleError("CreativeEventAnalysis", e, 
                "Player: " + player.getName());
            return false;
        }
    }
    
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
    public void onInventoryClick(@NotNull InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        
        if (player.hasPermission("crashguard.bypass")) {
            return;
        }
        
        ItemStack currentItem = event.getCurrentItem();
        ItemStack cursorItem = event.getCursor();
        
        if (currentItem != null && !crashDetector.isItemSafe(currentItem, player)) {
            event.setCancelled(true);
            protectionManager.handleViolation(player, "Malicious item detected in inventory click");
            return;
        }
        
        if (cursorItem != null && !crashDetector.isItemSafe(cursorItem, player)) {
            event.setCancelled(true);
            protectionManager.handleViolation(player, "Malicious cursor item detected");
            return;
        }
    }
    
    private boolean isInvalidSlot(int slot) {
        return slot < -1 || slot > 45 || slot == -999 || slot == -100 || slot == -37 || slot == -106;
    }
    
    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerJoin(@NotNull PlayerJoinEvent event) {
        String playerName = event.getPlayer().getName();
        invalidSlotAttempts.put(playerName, new AtomicInteger(0));
        lastEventTime.put(playerName, new AtomicLong(System.currentTimeMillis()));
        creativeEventCount.put(playerName, new AtomicInteger(0));
        rateLimiter.initializePlayer(playerName);
    }
    
    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerQuit(@NotNull PlayerQuitEvent event) {
        String playerName = event.getPlayer().getName();
        invalidSlotAttempts.remove(playerName);
        lastEventTime.remove(playerName);
        creativeEventCount.remove(playerName);
        rateLimiter.cleanupPlayer(playerName);
    }
    
    public void shutdown() {
        if (executorService != null && !executorService.isShutdown()) {
            executorService.shutdown();
            try {
                if (!executorService.awaitTermination(5, java.util.concurrent.TimeUnit.SECONDS)) {
                    executorService.shutdownNow();
                }
            } catch (InterruptedException e) {
                executorService.shutdownNow();
                Thread.currentThread().interrupt();
            }
        }
        
        invalidSlotAttempts.clear();
        lastEventTime.clear();
        creativeEventCount.clear();
    }
}
