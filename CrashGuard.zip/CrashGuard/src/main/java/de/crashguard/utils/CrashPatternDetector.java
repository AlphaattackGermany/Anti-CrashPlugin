package de.crashguard.utils;

import de.crashguard.CrashGuardPlugin;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.BookMeta;
import org.bukkit.inventory.meta.BundleMeta;
import org.bukkit.inventory.meta.BlockStateMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.jetbrains.annotations.NotNull;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

public final class CrashPatternDetector {
    
    private final CrashGuardPlugin plugin;
    private final Map<String, Integer> playerViolationCount;
    private final Set<String> dangerousNbtKeys;
    private final Set<Material> restrictedMaterials;
    private final List<Pattern> maliciousPatterns;
    
    private static final int MAX_ITEM_AMOUNT = 64;
    private static final int MAX_ENCHANT_LEVEL = 32767;
    private static final int MAX_DURABILITY = 32767;
    private static final int MAX_CUSTOM_MODEL_DATA = 2147483647;
    
    public CrashPatternDetector(@NotNull CrashGuardPlugin plugin) {
        this.plugin = plugin;
        this.playerViolationCount = new ConcurrentHashMap<>();
        this.dangerousNbtKeys = initializeDangerousKeys();
        this.restrictedMaterials = initializeRestrictedMaterials();
        this.maliciousPatterns = initializeMaliciousPatterns();
    }
    
    private Set<String> initializeDangerousKeys() {
        Set<String> keys = new HashSet<>();
        keys.addAll(Arrays.asList(
            "Items", "BlockEntityTag", "CanDestroy", "CanPlaceOn", "CustomPotionEffects",
            "Explosion", "Fireworks", "pages", "generation", "author", "title", "resolved",
            "EntityTag", "SkullOwner", "display", "HideFlags", "Unbreakable", "Damage",
            "RepairCost", "AttributeModifiers", "CustomModelData", "Enchantments", "StoredEnchantments",
            "Potion", "CustomPotionColor", "BucketVariantTag", "LodestoneDimension", "LodestonePos",
            "LodestoneTracked", "map", "Decorations", "MapColor", "DebugProperty", "ChargedProjectiles",
            "Charged", "SuspiciousStewEffects", "BlockStateTag", "TileEntityData", "BeeEntityData",
            "Bees", "FlowerPos", "HasNectar", "HasStung", "TicksSincePollination", "CannotEnterHiveTicks"
        ));
        return keys;
    }
    
    private Set<Material> initializeRestrictedMaterials() {
        Set<Material> materials = new HashSet<>();
        materials.addAll(Arrays.asList(
            Material.COMMAND_BLOCK, Material.CHAIN_COMMAND_BLOCK, Material.REPEATING_COMMAND_BLOCK,
            Material.COMMAND_BLOCK_MINECART, Material.STRUCTURE_BLOCK, Material.JIGSAW,
            Material.BARRIER, Material.BEDROCK, Material.END_PORTAL_FRAME, Material.END_PORTAL,
            Material.NETHER_PORTAL, Material.SPAWNER, Material.BUNDLE, Material.KNOWLEDGE_BOOK,
            Material.DEBUG_STICK, Material.WRITTEN_BOOK, Material.WRITABLE_BOOK
        ));
        return materials;
    }
    
    private List<Pattern> initializeMaliciousPatterns() {
        List<Pattern> patterns = new ArrayList<>();
        String[] maliciousStrings = {
            "crash", "exploit", "lag", "ddos", "overflow", "spam", "flood", "bomb",
            "\\\\u0000", "\\\\x00", "\u0000", "§k§k§k§k§k", "\\n\\n\\n\\n\\n",
            "ramcrash", "clientcrash", "servercrash", "memorycrash", "cpucrash",
            "packetspam", "nbtbomb", "bundlecrash", "shulkercrash", "bookcrash",
            "signcrash", "anvilcrash", "hoppercrash", "pistoncrash", "redstonecrash",
            "entitycrash", "chunkcrash", "worldcrash", "dimensioncrash", "portalcrash",
            "commandcrash", "scoreboardcrash", "teamcrash", "bossbarcrash", "titlecrash",
            "actionbarcrash", "chatcrash", "tablistcrash", "skincrash", "capecrash",
            "resourcepackcrash", "datapackcrash", "plugincrash", "modcrash", "fabriccrash",
            "forgecrash", "quiltcrash", "bukkitcrash", "spigotcrash", "papercrash",
            "velocitycrash", "waterfallcrash", "bungeecordcrash", "proxycrash", "networkcrash",
            "connectioncrash", "socketcrash", "channelcrash", "pipelinecrash", "handlercrash",
            "codeccrash", "encodercrash", "decodercrash", "serializercrash", "deserializercrash",
            "jsoncrash", "yamlcrash", "xmlcrash", "configcrash", "databasecrash",
            "sqlcrash", "mysqlcrash", "postgrescrash", "mongodbcrash", "rediscrash",
            "memcachedcrash", "elasticsearchcrash", "solrcrash", "lucenecrash", "hibernatecrash",
            "springcrash", "tomcatcrash", "jettycrash", "nettycrash", "undertowcrash",
            "vertxcrash", "akkacrash", "rxjavacrash", "reactorcrash", "kotlincrash",
            "scalacrash", "groovycrash", "clojurecrash", "jrubycrash", "jythoncrash",
            "nashhorncrash", "graalcrash", "jvmcrash", "hotspotcrash", "openj9crash",
            "gccrash", "heapcrash", "stackcrash", "permgencrash", "metaspacecrash",
            "directmemorycrash", "offheapcrash", "niocrash", "aiocrash", "epollcrash",
            "kqueuecrash", "ioringcrash", "selectcrash", "pollcrash", "threadscrash",
            "executorcrash", "schedulercrash", "timercrash", "futurecrash", "promisecrash",
            "completablefuturecrash", "observablecrash", "flowablecrash", "singlecrash", "maybecrash",
            "completablecrash", "monocrash", "fluxcrash", "publishercrash", "subscribercrash",
            "processorcrash", "operatorcrash", "transformercrash", "filtercrash", "mappercrash"
        };
        
        for (String maliciousString : maliciousStrings) {
            patterns.add(Pattern.compile(Pattern.quote(maliciousString), Pattern.CASE_INSENSITIVE));
        }
        
        return patterns;
    }
    
    public boolean isItemSafe(@NotNull ItemStack item, @NotNull Player player) {
        if (item == null || item.getType() == Material.AIR) {
            return true;
        }
        
        try {
            if (!checkBasicItemProperties(item)) return false;
            if (!checkMaterialRestrictions(item)) return false;
            if (!checkItemMeta(item)) return false;
            if (!checkSpecialItems(item)) return false;
            if (!checkMaliciousContent(item)) return false;
            
            return true;
        } catch (Exception e) {
            plugin.getLogger().warning("Error checking item safety: " + e.getMessage());
            return false;
        }
    }
    
    private boolean checkBasicItemProperties(@NotNull ItemStack item) {
        if (item.getAmount() > MAX_ITEM_AMOUNT || item.getAmount() < 1) {
            return false;
        }
        
        if (item.getDurability() > MAX_DURABILITY || item.getDurability() < 0) {
            return false;
        }
        
        return true;
    }
    
    private boolean checkMaterialRestrictions(@NotNull ItemStack item) {
        return !restrictedMaterials.contains(item.getType());
    }
    
    private boolean checkItemMeta(@NotNull ItemStack item) {
        if (!item.hasItemMeta()) {
            return true;
        }
        
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return true;
        }
        
        if (meta.hasDisplayName()) {
            String displayName = meta.getDisplayName();
            if (displayName.length() > 256 || containsMaliciousPattern(displayName)) {
                return false;
            }
        }
        
        if (meta.hasLore()) {
            List<String> lore = meta.getLore();
            if (lore != null) {
                if (lore.size() > 100) {
                    return false;
                }
                for (String line : lore) {
                    if (line.length() > 256 || containsMaliciousPattern(line)) {
                        return false;
                    }
                }
            }
        }
        
        if (meta.hasEnchants()) {
            for (int level : meta.getEnchants().values()) {
                if (level > MAX_ENCHANT_LEVEL || level < 0) {
                    return false;
                }
            }
        }
        
        if (meta.hasCustomModelData()) {
            int customModelData = meta.getCustomModelData();
            if (customModelData > MAX_CUSTOM_MODEL_DATA || customModelData < 0) {
                return false;
            }
        }
        
        return checkPersistentData(meta);
    }
    
    private boolean checkPersistentData(@NotNull ItemMeta meta) {
        PersistentDataContainer container = meta.getPersistentDataContainer();
        if (container.isEmpty()) {
            return true;
        }
        
        int totalSize = 0;
        for (var key : container.getKeys()) {
            totalSize += key.toString().length();
            
            if (dangerousNbtKeys.contains(key.getKey())) {
                return false;
            }
            
            if (container.has(key, PersistentDataType.STRING)) {
                String value = container.get(key, PersistentDataType.STRING);
                if (value != null) {
                    totalSize += value.length();
                    if (containsMaliciousPattern(value)) {
                        return false;
                    }
                }
            }
            
            if (totalSize > 65536) {
                return false;
            }
        }
        
        return true;
    }
    
    private boolean checkSpecialItems(@NotNull ItemStack item) {
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return true;
        }
        
        if (meta instanceof BookMeta bookMeta) {
            return checkBookMeta(bookMeta);
        }
        
        if (meta instanceof BundleMeta bundleMeta) {
            return checkBundleMeta(bundleMeta);
        }
        
        if (meta instanceof BlockStateMeta blockStateMeta) {
            return checkBlockStateMeta(blockStateMeta);
        }
        
        return true;
    }
    
    private boolean checkBookMeta(@NotNull BookMeta bookMeta) {
        if (bookMeta.hasPages()) {
            List<String> pages = bookMeta.getPages();
            if (pages.size() > 100) {
                return false;
            }
            
            for (String page : pages) {
                if (page.length() > 32767 || containsMaliciousPattern(page)) {
                    return false;
                }
            }
        }
        
        if (bookMeta.hasTitle()) {
            String title = bookMeta.getTitle();
            if (title.length() > 32 || containsMaliciousPattern(title)) {
                return false;
            }
        }
        
        if (bookMeta.hasAuthor()) {
            String author = bookMeta.getAuthor();
            if (author.length() > 16 || containsMaliciousPattern(author)) {
                return false;
            }
        }
        
        return true;
    }
    
    private boolean checkBundleMeta(@NotNull BundleMeta bundleMeta) {
        if (bundleMeta.hasItems()) {
            List<ItemStack> items = bundleMeta.getItems();
            if (items.size() > 64) {
                return false;
            }
            
            for (ItemStack bundleItem : items) {
                if (bundleItem != null && bundleItem.getType() == Material.BUNDLE) {
                    return false;
                }
            }
        }
        
        return true;
    }
    
    private boolean checkBlockStateMeta(@NotNull BlockStateMeta blockStateMeta) {
        try {
            if (blockStateMeta.hasBlockState()) {
                return blockStateMeta.getBlockState() != null;
            }
        } catch (Exception e) {
            return false;
        }
        
        return true;
    }
    
    private boolean checkMaliciousContent(@NotNull ItemStack item) {
        String itemString = item.toString().toLowerCase();
        
        for (Pattern pattern : maliciousPatterns) {
            if (pattern.matcher(itemString).find()) {
                return false;
            }
        }
        
        return true;
    }
    
    private boolean containsMaliciousPattern(@NotNull String text) {
        String lowerText = text.toLowerCase();
        
        for (Pattern pattern : maliciousPatterns) {
            if (pattern.matcher(lowerText).find()) {
                return true;
            }
        }
        
        int controlCharCount = 0;
        for (char c : text.toCharArray()) {
            if (Character.isISOControl(c) && c != '\n' && c != '\r' && c != '\t') {
                controlCharCount++;
                if (controlCharCount > 10) {
                    return true;
                }
            }
        }
        
        return text.length() > 32767 || text.contains("\u0000") || 
               text.contains("§k§k§k§k§k") || text.matches(".*\\\\u0000.*");
    }
}
