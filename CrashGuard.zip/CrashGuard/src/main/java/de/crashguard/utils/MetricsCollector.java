package de.crashguard.utils;

import java.util.concurrent.atomic.AtomicLong;

public final class MetricsCollector {
    
    private final AtomicLong packetsProcessed;
    private final AtomicLong violationsDetected;
    private final AtomicLong playersKicked;
    private final AtomicLong startTime;
    
    public MetricsCollector() {
        this.packetsProcessed = new AtomicLong(0);
        this.violationsDetected = new AtomicLong(0);
        this.playersKicked = new AtomicLong(0);
        this.startTime = new AtomicLong(System.currentTimeMillis());
    }
    
    public void incrementPacketsProcessed() {
        packetsProcessed.incrementAndGet();
    }
    
    public void incrementViolationsDetected() {
        violationsDetected.incrementAndGet();
    }
    
    public void incrementPlayersKicked() {
        playersKicked.incrementAndGet();
    }
    
    public long getPacketsProcessed() {
        return packetsProcessed.get();
    }
    
    public long getViolationsDetected() {
        return violationsDetected.get();
    }
    
    public long getPlayersKicked() {
        return playersKicked.get();
    }
    
    public long getUptimeMillis() {
        return System.currentTimeMillis() - startTime.get();
    }
    
    public double getPacketsPerSecond() {
        long uptime = getUptimeMillis();
        if (uptime == 0) return 0.0;
        return (double) packetsProcessed.get() / (uptime / 1000.0);
    }
    
    public void reset() {
        packetsProcessed.set(0);
        violationsDetected.set(0);
        playersKicked.set(0);
        startTime.set(System.currentTimeMillis());
    }
    
    public void shutdown() {
        
    }
}
