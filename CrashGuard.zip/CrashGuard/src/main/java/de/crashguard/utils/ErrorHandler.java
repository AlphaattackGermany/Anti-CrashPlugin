package de.crashguard.utils;

import de.crashguard.CrashGuardPlugin;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;

public final class ErrorHandler {
    
    private final CrashGuardPlugin plugin;
    private final ConcurrentHashMap<String, AtomicInteger> errorCounts;
    private final ConcurrentHashMap<String, Long> lastErrorTime;
    
    private static final int MAX_ERROR_COUNT = 10;
    private static final long ERROR_RESET_TIME = 300000L;
    
    public ErrorHandler(@NotNull CrashGuardPlugin plugin) {
        this.plugin = plugin;
        this.errorCounts = new ConcurrentHashMap<>();
        this.lastErrorTime = new ConcurrentHashMap<>();
        
        startErrorCleanup();
    }
    
    private void startErrorCleanup() {
        plugin.getServer().getScheduler().runTaskTimerAsynchronously(plugin, () -> {
            long currentTime = System.currentTimeMillis();
            
            lastErrorTime.entrySet().removeIf(entry -> {
                if (currentTime - entry.getValue() > ERROR_RESET_TIME) {
                    errorCounts.remove(entry.getKey());
                    return true;
                }
                return false;
            });
        }, 6000L, 6000L);
    }
    
    public void handleError(@NotNull String context, @NotNull Throwable throwable) {
        handleError(context, throwable, null);
    }
    
    public void handleError(@NotNull String context, @NotNull Throwable throwable, @Nullable String additionalInfo) {
        String errorKey = context + ":" + throwable.getClass().getSimpleName();
        
        AtomicInteger count = errorCounts.computeIfAbsent(errorKey, k -> new AtomicInteger(0));
        lastErrorTime.put(errorKey, System.currentTimeMillis());
        
        int currentCount = count.incrementAndGet();
        
        if (currentCount <= MAX_ERROR_COUNT) {
            Level logLevel = determineLogLevel(throwable, currentCount);
            
            StringBuilder message = new StringBuilder();
            message.append("Error in ").append(context).append(": ").append(throwable.getMessage());
            
            if (additionalInfo != null) {
                message.append(" | Additional info: ").append(additionalInfo);
            }
            
            if (currentCount > 1) {
                message.append(" (Count: ").append(currentCount).append(")");
            }
            
            plugin.getLogger().log(logLevel, message.toString(), 
                plugin.getConfigManager().isDebugEnabled() ? throwable : null);
            
            if (currentCount == MAX_ERROR_COUNT) {
                plugin.getLogger().warning("Error suppression activated for: " + errorKey + 
                    " (reached maximum count of " + MAX_ERROR_COUNT + ")");
            }
        }
        
        if (isCriticalError(throwable)) {
            handleCriticalError(context, throwable, additionalInfo);
        }
    }
    
    private Level determineLogLevel(@NotNull Throwable throwable, int count) {
        if (isCriticalError(throwable)) {
            return Level.SEVERE;
        }
        
        if (count > 5) {
            return Level.WARNING;
        }
        
        if (throwable instanceof IllegalArgumentException || 
            throwable instanceof IllegalStateException) {
            return Level.WARNING;
        }
        
        return Level.INFO;
    }
    
    private boolean isCriticalError(@NotNull Throwable throwable) {
        return throwable instanceof OutOfMemoryError ||
               throwable instanceof StackOverflowError ||
               throwable instanceof NoClassDefFoundError ||
               throwable instanceof ExceptionInInitializerError ||
               (throwable instanceof RuntimeException && 
                throwable.getMessage() != null && 
                throwable.getMessage().toLowerCase().contains("crash"));
    }
    
    private void handleCriticalError(@NotNull String context, @NotNull Throwable throwable, @Nullable String additionalInfo) {
        plugin.getLogger().severe("CRITICAL ERROR detected in " + context + "!");
        plugin.getLogger().severe("Error type: " + throwable.getClass().getSimpleName());
        plugin.getLogger().severe("Error message: " + throwable.getMessage());
        
        if (additionalInfo != null) {
            plugin.getLogger().severe("Additional context: " + additionalInfo);
        }
        
        if (throwable instanceof OutOfMemoryError) {
            plugin.getLogger().severe("OUT OF MEMORY ERROR - Consider increasing heap size!");
            System.gc();
        }
        
        if (throwable instanceof StackOverflowError) {
            plugin.getLogger().severe("STACK OVERFLOW ERROR - Possible infinite recursion!");
        }
        
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            plugin.getServer().getOnlinePlayers().stream()
                .filter(player -> player.hasPermission("crashguard.notify"))
                .forEach(player -> player.sendMessage(
                    "§c[CrashGuard] §4CRITICAL ERROR: §c" + throwable.getClass().getSimpleName() + 
                    " in " + context));
        });
    }
    
    public void handleSafeError(@NotNull String context, @NotNull String message) {
        if (plugin.getConfigManager().shouldLogBlockedAttempts()) {
            plugin.getLogger().info("[" + context + "] " + message);
        }
    }
    
    public void handleWarning(@NotNull String context, @NotNull String message) {
        plugin.getLogger().warning("[" + context + "] " + message);
    }
    
    public void handleDebug(@NotNull String context, @NotNull String message) {
        if (plugin.getConfigManager().isDebugEnabled()) {
            plugin.getLogger().info("[DEBUG] [" + context + "] " + message);
        }
    }
    
    public boolean shouldSuppressError(@NotNull String context, @NotNull Throwable throwable) {
        String errorKey = context + ":" + throwable.getClass().getSimpleName();
        AtomicInteger count = errorCounts.get(errorKey);
        return count != null && count.get() > MAX_ERROR_COUNT;
    }
    
    public void resetErrorCount(@NotNull String context, @NotNull Class<? extends Throwable> throwableClass) {
        String errorKey = context + ":" + throwableClass.getSimpleName();
        errorCounts.remove(errorKey);
        lastErrorTime.remove(errorKey);
    }
    
    public void resetAllErrorCounts() {
        errorCounts.clear();
        lastErrorTime.clear();
        plugin.getLogger().info("All error counts have been reset");
    }
    
    public int getErrorCount(@NotNull String context, @NotNull Class<? extends Throwable> throwableClass) {
        String errorKey = context + ":" + throwableClass.getSimpleName();
        AtomicInteger count = errorCounts.get(errorKey);
        return count != null ? count.get() : 0;
    }
}
