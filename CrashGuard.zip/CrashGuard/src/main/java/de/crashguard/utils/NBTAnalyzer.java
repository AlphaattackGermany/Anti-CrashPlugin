package de.crashguard.utils;

import de.crashguard.CrashGuardPlugin;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class NBTAnalyzer {
    
    private final CrashGuardPlugin plugin;
    private final Map<String, Boolean> itemStackCache;
    private final Map<String, Long> cacheTimestamps;
    
    private static final long CACHE_EXPIRY_TIME = 300000L;
    private static final int MAX_STRING_LENGTH = 32767;
    private static final int MAX_LIST_SIZE = 1024;
    private static final String[] DANGEROUS_NBT_KEYS = {
        "Items", "BlockEntityTag", "CanDestroy", "CanPlaceOn", 
        "CustomPotionEffects", "Explosion", "Fireworks", "pages"
    };
    
    public NBTAnalyzer(@NotNull CrashGuardPlugin plugin) {
        this.plugin = plugin;
        this.itemStackCache = new ConcurrentHashMap<>();
        this.cacheTimestamps = new ConcurrentHashMap<>();
        
        startCacheCleanupTask();
    }
    
    private void startCacheCleanupTask() {
        plugin.getServer().getScheduler().runTaskTimerAsynchronously(plugin, () -> {
            long currentTime = System.currentTimeMillis();
            cacheTimestamps.entrySet().removeIf(entry -> {
                if (currentTime - entry.getValue() > CACHE_EXPIRY_TIME) {
                    itemStackCache.remove(entry.getKey());
                    return true;
                }
                return false;
            });
        }, 6000L, 6000L);
    }
    
    public boolean isItemStackSafe(@NotNull ItemStack itemStack) {
        if (itemStack == null || itemStack.getType() == Material.AIR) {
            return true;
        }
        
        if (isWhitelistedItem(itemStack)) {
            return true;
        }
        
        String cacheKey = generateCacheKey(itemStack);
        Boolean cachedResult = itemStackCache.get(cacheKey);
        
        if (cachedResult != null) {
            cacheTimestamps.put(cacheKey, System.currentTimeMillis());
            return cachedResult;
        }
        
        boolean isSafe = performSafetyAnalysis(itemStack);
        
        if (itemStackCache.size() < plugin.getConfigManager().getCacheSize()) {
            itemStackCache.put(cacheKey, isSafe);
            cacheTimestamps.put(cacheKey, System.currentTimeMillis());
        }
        
        return isSafe;
    }
    
    private boolean isWhitelistedItem(@NotNull ItemStack itemStack) {
        if (!itemStack.hasItemMeta()) {
            return isBasicMaterialSafe(itemStack.getType());
        }
        
        ItemMeta meta = itemStack.getItemMeta();
        if (meta == null) {
            return isBasicMaterialSafe(itemStack.getType());
        }
        
        if (!meta.hasDisplayName() && !meta.hasLore() && !meta.hasEnchants() && 
            !meta.hasCustomModelData() && meta.getPersistentDataContainer().isEmpty()) {
            return isBasicMaterialSafe(itemStack.getType());
        }
        
        return false;
    }
    
    private boolean isBasicMaterialSafe(@NotNull Material material) {
        return !material.name().contains("COMMAND") && 
               !material.name().contains("STRUCTURE") &&
               material != Material.BARRIER &&
               material != Material.BEDROCK &&
               material != Material.SPAWNER &&
               material != Material.DEBUG_STICK;
    }
    
    private boolean performSafetyAnalysis(@NotNull ItemStack itemStack) {
        if (!hasItemMeta(itemStack)) {
            return true;
        }
        
        ItemMeta meta = itemStack.getItemMeta();
        if (meta == null) {
            return true;
        }
        
        if (!analyzeDisplayName(meta)) {
            return false;
        }
        
        if (!analyzeLore(meta)) {
            return false;
        }
        
        if (!analyzePersistentData(meta)) {
            return false;
        }
        
        if (itemStack.getType() == Material.BUNDLE) {
            if (!analyzeBundleContents(itemStack)) {
                return false;
            }
        }
        
        if (isShulkerBox(itemStack.getType())) {
            if (!analyzeShulkerBoxContents(meta)) {
                return false;
            }
        }
        
        return analyzeCustomModelData(meta) && analyzeEnchantments(meta);
    }
    
    private boolean hasItemMeta(@NotNull ItemStack itemStack) {
        return itemStack.hasItemMeta();
    }
    
    private boolean analyzeDisplayName(@NotNull ItemMeta meta) {
        if (!meta.hasDisplayName()) {
            return true;
        }
        
        String displayName = meta.getDisplayName();
        return displayName.length() <= MAX_STRING_LENGTH && 
               !containsSuspiciousPatterns(displayName);
    }
    
    private boolean analyzeLore(@NotNull ItemMeta meta) {
        if (!meta.hasLore()) {
            return true;
        }
        
        List<String> lore = meta.getLore();
        if (lore == null || lore.size() > MAX_LIST_SIZE) {
            return false;
        }
        
        for (String line : lore) {
            if (line.length() > MAX_STRING_LENGTH || containsSuspiciousPatterns(line)) {
                return false;
            }
        }
        
        return true;
    }
    
    private boolean analyzePersistentData(@NotNull ItemMeta meta) {
        PersistentDataContainer container = meta.getPersistentDataContainer();
        
        if (container.isEmpty()) {
            return true;
        }
        
        try {
            int dataSize = calculatePersistentDataSize(container);
            return dataSize <= plugin.getConfigManager().getMaxNbtSize();
        } catch (Exception e) {
            return false;
        }
    }
    
    private int calculatePersistentDataSize(@NotNull PersistentDataContainer container) {
        int totalSize = 0;
        
        for (var key : container.getKeys()) {
            totalSize += key.toString().length();
            
            if (container.has(key, PersistentDataType.STRING)) {
                String value = container.get(key, PersistentDataType.STRING);
                if (value != null) {
                    totalSize += value.length();
                }
            } else if (container.has(key, PersistentDataType.BYTE_ARRAY)) {
                byte[] value = container.get(key, PersistentDataType.BYTE_ARRAY);
                if (value != null) {
                    totalSize += value.length;
                }
            }
            
            if (totalSize > plugin.getConfigManager().getMaxNbtSize()) {
                return totalSize;
            }
        }
        
        return totalSize;
    }
    
    private boolean analyzeBundleContents(@NotNull ItemStack bundle) {
        try {
            ItemMeta meta = bundle.getItemMeta();
            if (meta == null) return true;
            
            PersistentDataContainer container = meta.getPersistentDataContainer();
            
            for (var key : container.getKeys()) {
                if (key.getKey().contains("bundle") || key.getKey().contains("contents")) {
                    byte[] data = container.get(key, PersistentDataType.BYTE_ARRAY);
                    if (data != null && data.length > plugin.getConfigManager().getMaxNbtSize()) {
                        return false;
                    }
                }
            }
            
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    
    private boolean isShulkerBox(@NotNull Material material) {
        return material.name().contains("SHULKER_BOX");
    }
    
    private boolean analyzeShulkerBoxContents(@NotNull ItemMeta meta) {
        PersistentDataContainer container = meta.getPersistentDataContainer();
        
        for (var key : container.getKeys()) {
            String keyString = key.toString();
            
            for (String dangerousKey : DANGEROUS_NBT_KEYS) {
                if (keyString.contains(dangerousKey.toLowerCase())) {
                    byte[] data = container.get(key, PersistentDataType.BYTE_ARRAY);
                    if (data != null && data.length > plugin.getConfigManager().getMaxNbtSize() / 2) {
                        return false;
                    }
                }
            }
        }
        
        return true;
    }
    
    private boolean analyzeCustomModelData(@NotNull ItemMeta meta) {
        if (!meta.hasCustomModelData()) {
            return true;
        }
        
        int customModelData = meta.getCustomModelData();
        return customModelData >= 0 && customModelData <= 2147483647;
    }
    
    private boolean analyzeEnchantments(@NotNull ItemMeta meta) {
        if (!meta.hasEnchants()) {
            return true;
        }
        
        return meta.getEnchants().size() <= 50 && 
               meta.getEnchants().values().stream().allMatch(level -> level <= 32767);
    }
    
    private boolean containsSuspiciousPatterns(@NotNull String text) {
        if (text.length() < 3) {
            return false;
        }
        
        String lowerText = text.toLowerCase();
        
        if (isLegitimateText(lowerText)) {
            return false;
        }
        
        String[] highRiskPatterns = {
            "ramcrash", "clientcrash", "servercrash", "crashclient", "exploitpack",
            "nbtbomb", "bundlecrash", "packetspam", "memoryoverflow", "stackoverflow"
        };
        
        for (String pattern : highRiskPatterns) {
            if (lowerText.contains(pattern)) {
                return true;
            }
        }
        
        String[] mediumRiskPatterns = {
            "\\u0000", "\\x00", "\u0000", "§k§k§k§k§k", "\\n\\n\\n\\n\\n"
        };
        
        for (String pattern : mediumRiskPatterns) {
            if (lowerText.contains(pattern)) {
                return true;
            }
        }
        
        int controlCharCount = 0;
        int consecutiveControlChars = 0;
        for (char c : text.toCharArray()) {
            if (Character.isISOControl(c) && c != '\n' && c != '\r' && c != '\t') {
                controlCharCount++;
                consecutiveControlChars++;
                if (consecutiveControlChars > 3 || controlCharCount > 10) {
                    return true;
                }
            } else {
                consecutiveControlChars = 0;
            }
        }
        
        return hasExcessiveRepetition(text) || hasExcessiveSpecialChars(text);
    }
    
    private boolean isLegitimateText(@NotNull String text) {
        String[] legitimateWords = {
            "diamond", "sword", "pickaxe", "axe", "shovel", "hoe", "helmet", "chestplate",
            "leggings", "boots", "bow", "arrow", "shield", "trident", "crossbow", "mace",
            "enchanted", "unbreaking", "efficiency", "fortune", "silk", "touch", "sharpness",
            "protection", "thorns", "respiration", "aqua", "affinity", "depth", "strider",
            "frost", "walker", "feather", "falling", "fire", "aspect", "knockback", "looting",
            "sweeping", "edge", "impaling", "loyalty", "riptide", "channeling", "multishot",
            "piercing", "quick", "charge", "punch", "power", "flame", "infinity", "mending",
            "curse", "vanishing", "binding", "minecraft", "crafting", "smelting", "brewing",
            "trading", "fishing", "farming", "mining", "building", "exploring", "adventure"
        };
        
        for (String word : legitimateWords) {
            if (text.contains(word)) {
                return true;
            }
        }
        
        return false;
    }
    
    private boolean hasExcessiveRepetition(@NotNull String text) {
        if (text.length() < 10) {
            return false;
        }
        
        for (int i = 1; i <= text.length() / 2; i++) {
            String pattern = text.substring(0, i);
            int repetitions = 0;
            int pos = 0;
            
            while (pos + pattern.length() <= text.length()) {
                if (text.substring(pos, pos + pattern.length()).equals(pattern)) {
                    repetitions++;
                    pos += pattern.length();
                } else {
                    break;
                }
            }
            
            if (repetitions > 20 && pattern.length() > 1) {
                return true;
            }
        }
        
        return false;
    }
    
    private boolean hasExcessiveSpecialChars(@NotNull String text) {
        int specialCharCount = 0;
        for (char c : text.toCharArray()) {
            if (!Character.isLetterOrDigit(c) && !Character.isWhitespace(c) && 
                c != '§' && c != '&' && c != '-' && c != '_' && c != '.' && c != '!' && c != '?') {
                specialCharCount++;
            }
        }
        
        return specialCharCount > text.length() * 0.3;
    }
    
    private String generateCacheKey(@NotNull ItemStack itemStack) {
        StringBuilder keyBuilder = new StringBuilder();
        keyBuilder.append(itemStack.getType().name())
                  .append(":")
                  .append(itemStack.getAmount())
                  .append(":");
        
        if (itemStack.hasItemMeta()) {
            ItemMeta meta = itemStack.getItemMeta();
            if (meta != null) {
                keyBuilder.append(meta.hashCode());
            }
        }
        
        return keyBuilder.toString();
    }
}
