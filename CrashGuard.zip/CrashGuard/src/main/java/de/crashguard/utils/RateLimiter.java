package de.crashguard.utils;

import de.crashguard.CrashGuardPlugin;
import org.jetbrains.annotations.NotNull;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

public final class RateLimiter {
    
    private final CrashGuardPlugin plugin;
    private final ConcurrentHashMap<String, TokenBucket> playerBuckets;
    private final ConcurrentHashMap<String, AtomicLong> lastResetTime;
    
    private static final long RESET_INTERVAL = 1000L;
    
    public RateLimiter(@NotNull CrashGuardPlugin plugin) {
        this.plugin = plugin;
        this.playerBuckets = new ConcurrentHashMap<>();
        this.lastResetTime = new ConcurrentHashMap<>();
        
        startCleanupTask();
    }
    
    private void startCleanupTask() {
        plugin.getServer().getScheduler().runTaskTimerAsynchronously(plugin, () -> {
            long currentTime = System.currentTimeMillis();
            
            lastResetTime.entrySet().removeIf(entry -> {
                if (currentTime - entry.getValue().get() > 300000L) {
                    playerBuckets.remove(entry.getKey());
                    return true;
                }
                return false;
            });
        }, 6000L, 6000L);
    }
    
    public void initializePlayer(@NotNull String playerName) {
        int maxPackets = plugin.getConfigManager().getMaxPacketsPerSecond();
        playerBuckets.put(playerName, new TokenBucket(maxPackets));
        lastResetTime.put(playerName, new AtomicLong(System.currentTimeMillis()));
    }
    
    public void cleanupPlayer(@NotNull String playerName) {
        playerBuckets.remove(playerName);
        lastResetTime.remove(playerName);
    }
    
    public boolean isAllowed(@NotNull String playerName) {
        TokenBucket bucket = playerBuckets.get(playerName);
        AtomicLong lastReset = lastResetTime.get(playerName);
        
        if (bucket == null || lastReset == null) {
            initializePlayer(playerName);
            bucket = playerBuckets.get(playerName);
            lastReset = lastResetTime.get(playerName);
        }
        
        long currentTime = System.currentTimeMillis();
        long timeSinceReset = currentTime - lastReset.get();
        
        if (timeSinceReset >= RESET_INTERVAL) {
            bucket.refill();
            lastReset.set(currentTime);
        }
        
        return bucket.tryConsume();
    }
    
    private static final class TokenBucket {
        private final int capacity;
        private final AtomicInteger tokens;
        
        public TokenBucket(int capacity) {
            this.capacity = capacity;
            this.tokens = new AtomicInteger(capacity);
        }
        
        public boolean tryConsume() {
            int currentTokens = tokens.get();
            if (currentTokens > 0) {
                return tokens.compareAndSet(currentTokens, currentTokens - 1);
            }
            return false;
        }
        
        public void refill() {
            tokens.set(capacity);
        }
    }
}
