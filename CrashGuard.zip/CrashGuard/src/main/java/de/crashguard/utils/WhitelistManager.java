package de.crashguard.utils;

import de.crashguard.CrashGuardPlugin;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.jetbrains.annotations.NotNull;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public final class WhitelistManager {
    
    private final CrashGuardPlugin plugin;
    private final Set<Material> whitelistedMaterials;
    private final Set<String> whitelistedPlayers;
    private final ConcurrentHashMap<String, Long> playerWhitelistCache;
    
    private static final long CACHE_DURATION = 60000L;
    
    public WhitelistManager(@NotNull CrashGuardPlugin plugin) {
        this.plugin = plugin;
        this.whitelistedMaterials = new HashSet<>();
        this.whitelistedPlayers = new HashSet<>();
        this.playerWhitelistCache = new ConcurrentHashMap<>();
        
        loadWhitelists();
        startCacheCleanup();
    }
    
    private void loadWhitelists() {
        whitelistedMaterials.clear();
        whitelistedPlayers.clear();
        
        List<String> materials = plugin.getConfig().getStringList("whitelist.materials");
        for (String materialName : materials) {
            try {
                Material material = Material.valueOf(materialName.toUpperCase());
                whitelistedMaterials.add(material);
            } catch (IllegalArgumentException e) {
                plugin.getLogger().warning("Invalid material in whitelist: " + materialName);
            }
        }
        
        List<String> players = plugin.getConfig().getStringList("whitelist.players");
        for (String playerName : players) {
            whitelistedPlayers.add(playerName.toLowerCase());
        }
        
        addDefaultWhitelistedMaterials();
    }
    
    private void addDefaultWhitelistedMaterials() {
        Material[] defaultMaterials = {
            Material.STONE, Material.DIRT, Material.GRASS_BLOCK, Material.COBBLESTONE,
            Material.OAK_PLANKS, Material.OAK_LOG, Material.OAK_LEAVES, Material.GLASS,
            Material.SAND, Material.GRAVEL, Material.IRON_ORE, Material.COAL_ORE,
            Material.DIAMOND_ORE, Material.GOLD_ORE, Material.REDSTONE_ORE, Material.LAPIS_ORE,
            Material.IRON_INGOT, Material.GOLD_INGOT, Material.DIAMOND, Material.COAL,
            Material.REDSTONE, Material.LAPIS_LAZULI, Material.EMERALD, Material.QUARTZ,
            Material.WOODEN_SWORD, Material.STONE_SWORD, Material.IRON_SWORD, Material.DIAMOND_SWORD,
            Material.WOODEN_PICKAXE, Material.STONE_PICKAXE, Material.IRON_PICKAXE, Material.DIAMOND_PICKAXE,
            Material.WOODEN_AXE, Material.STONE_AXE, Material.IRON_AXE, Material.DIAMOND_AXE,
            Material.WOODEN_SHOVEL, Material.STONE_SHOVEL, Material.IRON_SHOVEL, Material.DIAMOND_SHOVEL,
            Material.WOODEN_HOE, Material.STONE_HOE, Material.IRON_HOE, Material.DIAMOND_HOE,
            Material.LEATHER_HELMET, Material.LEATHER_CHESTPLATE, Material.LEATHER_LEGGINGS, Material.LEATHER_BOOTS,
            Material.IRON_HELMET, Material.IRON_CHESTPLATE, Material.IRON_LEGGINGS, Material.IRON_BOOTS,
            Material.DIAMOND_HELMET, Material.DIAMOND_CHESTPLATE, Material.DIAMOND_LEGGINGS, Material.DIAMOND_BOOTS,
            Material.BOW, Material.ARROW, Material.SHIELD, Material.FISHING_ROD, Material.BREAD,
            Material.COOKED_BEEF, Material.COOKED_PORKCHOP, Material.COOKED_CHICKEN, Material.APPLE,
            Material.GOLDEN_APPLE, Material.WATER_BUCKET, Material.LAVA_BUCKET, Material.MILK_BUCKET
        };
        
        for (Material material : defaultMaterials) {
            whitelistedMaterials.add(material);
        }
    }
    
    private void startCacheCleanup() {
        plugin.getServer().getScheduler().runTaskTimerAsynchronously(plugin, () -> {
            long currentTime = System.currentTimeMillis();
            playerWhitelistCache.entrySet().removeIf(entry -> 
                currentTime - entry.getValue() > CACHE_DURATION);
        }, 1200L, 1200L);
    }
    
    public boolean isPlayerWhitelisted(@NotNull Player player) {
        String playerName = player.getName().toLowerCase();
        
        Long cachedTime = playerWhitelistCache.get(playerName);
        if (cachedTime != null && System.currentTimeMillis() - cachedTime < CACHE_DURATION) {
            return true;
        }
        
        if (player.hasPermission("crashguard.bypass")) {
            playerWhitelistCache.put(playerName, System.currentTimeMillis());
            return true;
        }
        
        if (whitelistedPlayers.contains(playerName)) {
            playerWhitelistCache.put(playerName, System.currentTimeMillis());
            return true;
        }
        
        if (player.isOp() && plugin.getConfig().getBoolean("protection.false-positive-reduction.ignore-creative-players", false)) {
            playerWhitelistCache.put(playerName, System.currentTimeMillis());
            return true;
        }
        
        return false;
    }
    
    public boolean isMaterialWhitelisted(@NotNull Material material) {
        return whitelistedMaterials.contains(material);
    }
    
    public boolean isItemWhitelisted(@NotNull ItemStack item) {
        if (item == null || item.getType() == Material.AIR) {
            return true;
        }
        
        if (isMaterialWhitelisted(item.getType())) {
            return isBasicItem(item);
        }
        
        return false;
    }
    
    private boolean isBasicItem(@NotNull ItemStack item) {
        if (!item.hasItemMeta()) {
            return true;
        }
        
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return true;
        }
        
        if (plugin.getConfig().getBoolean("protection.false-positive-reduction.whitelist-enchanted-items", true)) {
            if (meta.hasEnchants() && !meta.hasDisplayName() && !meta.hasLore()) {
                return areEnchantmentsLegitimate(meta);
            }
        }
        
        if (meta.hasDisplayName() || meta.hasLore() || !meta.getPersistentDataContainer().isEmpty()) {
            return false;
        }
        
        return true;
    }
    
    private boolean areEnchantmentsLegitimate(@NotNull ItemMeta meta) {
        return meta.getEnchants().size() <= 10 && 
               meta.getEnchants().values().stream().allMatch(level -> level <= 5);
    }
    
    public void addWhitelistedMaterial(@NotNull Material material) {
        whitelistedMaterials.add(material);
        saveWhitelistToConfig();
    }
    
    public void removeWhitelistedMaterial(@NotNull Material material) {
        whitelistedMaterials.remove(material);
        saveWhitelistToConfig();
    }
    
    public void addWhitelistedPlayer(@NotNull String playerName) {
        whitelistedPlayers.add(playerName.toLowerCase());
        saveWhitelistToConfig();
    }
    
    public void removeWhitelistedPlayer(@NotNull String playerName) {
        whitelistedPlayers.remove(playerName.toLowerCase());
        playerWhitelistCache.remove(playerName.toLowerCase());
        saveWhitelistToConfig();
    }
    
    private void saveWhitelistToConfig() {
        List<String> materialNames = whitelistedMaterials.stream()
            .map(Material::name)
            .toList();
        
        plugin.getConfig().set("whitelist.materials", materialNames);
        plugin.getConfig().set("whitelist.players", whitelistedPlayers.stream().toList());
        plugin.saveConfig();
    }
    
    public void reloadWhitelists() {
        loadWhitelists();
    }
    
    public Set<Material> getWhitelistedMaterials() {
        return new HashSet<>(whitelistedMaterials);
    }
    
    public Set<String> getWhitelistedPlayers() {
        return new HashSet<>(whitelistedPlayers);
    }
}
